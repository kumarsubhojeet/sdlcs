/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      extend: {
        colors: {
          primecolor: "#1601AA",
          seccolor: "#44C6FE",
        },

      }
    },
  },
  plugins: [],
}