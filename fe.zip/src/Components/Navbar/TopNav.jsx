import React from 'react'
import {
  SendOutlined, UserOutlined, PoweroffOutlined, UserAddOutlined
} from '@ant-design/icons';
import { Button, Dropdown, Space } from 'antd';
import { Link } from "react-router-dom";


export default function index() {
  const items = [
    {
      key: '1',
      label: (<Link to='/login'>Logout</Link>),
      icon: <PoweroffOutlined />,

    },
    {
      key: '2',
      label: "Register",
      icon: <UserAddOutlined />,
    },
  ]

  return (
    <>
      <div className=' bg-[#002158] text-white py-5 px-5 flex items-center justify-between  '>
        <Link to='/'><div className='  text-2xl flex items-center '>
          <SendOutlined />
          <h1 className='TopNavFont pl-1 '> Weather World</h1>
        </div>
        </Link>
        <div>
          <Dropdown menu={{ items }}>
            <a onClick={(e) => e.preventDefault()}>
              <Space>
                <UserOutlined className=' text-2xl cursor-pointer ' />
              </Space>
            </a>
          </Dropdown>
        </div>
      </div>
    </>
  )
}
