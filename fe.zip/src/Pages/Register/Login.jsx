import React, { useState } from 'react'
import { UserOutlined, LockOutlined, MailOutlined } from '@ant-design/icons';
import { Input } from 'antd';
import login_logo from '../../Assets/Images/login.jpg'
import { Link, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from 'react-redux'
import { showLoading, hideLoading } from '../../Redux/Slice/alertSlice';
import Swal from 'sweetalert2'
import { Spin } from 'antd';
import axios from 'axios';


export default function Signup() {
  const [Email, setEmail] = useState('');
  const [Password, setPassword] = useState('');

  //redux loading 
  const { loading } = useSelector(state => state.alerts)
  //Dispatch
  const dispatch = useDispatch();
  const Navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (!Email || !Password) {
        return Swal.fire({
          icon: "question",
          title: "Details Not Provided",
          text: "Please Fill All Fields",
        });
      }
      dispatch(showLoading())
      const { data } = await axios.post(`/api/users/login`, { Email, Password })
      dispatch(hideLoading())
      if (data.success) {
        Swal.fire({
          position: "center",
          icon: "success",
          title: `${Email} Welcome`,
          showConfirmButton: false,
          timer: 1500
        });

        Navigate('/')
      }
    } catch (error) {
      dispatch(hideLoading())
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Something went wrong! Please try again later",
      });
    }
  }

  return (
    <div className='Shadow1 login_main lg:w-[30%] md:w-[90%] pt-10 rounded-xl mx-auto mt-10 '>

      <section className=' mx-auto '>
        <img src={login_logo} alt="error" className=' mx-auto bg-[#d6d4e6] p-7 rounded-full w-[100px] h-[100px] ' />
      </section>

      <section className='  w-[100%]  mx-auto py-10 px-10 top-[50%]   '>
        <form action="" onSubmit={handleSubmit} >
          <Input onChange={e => setEmail(e.target.value)} placeholder="Enter Email" type='email' prefix={<MailOutlined />} className=' mb-6 w-[100%] ' />
          <div className='flex items justify-between'>
            <Input onChange={e => setPassword(e.target.value)} placeholder="Enter Password" type="password" prefix={<LockOutlined />} className=' mb-6 w-[100%] ' />
          </div>


          <div className='flex items-center flex-col'>
            <button class="loginbtn" role="button" >Login</button>
            <Link to='/signup'><p className='pt-4'>Create New Account</p></Link>
          </div>
        </form>


      </section>


    </div>
  )
}
