import React, { useState, useEffect } from 'react'
import { UserOutlined, LockOutlined, MailOutlined } from '@ant-design/icons';
import { Input } from 'antd';
import axios from 'axios';
import login_logo from '../../Assets/Images/login.jpg'
import { Link, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from 'react-redux'
import { showLoading, hideLoading } from '../../Redux/Slice/alertSlice';
import Swal from 'sweetalert2'
import { Spin } from 'antd';

export default function Signup() {
  const [FirstName, setFirstName] = useState('');
  const [LastName, setLastName] = useState('');
  const [Email, setEmail] = useState('');
  const [Password, setPassword] = useState('');
  const [CPassword, setCPassword] = useState('');

  //redux loading 
  const { loading } = useSelector(state => state.alerts)
  //Dispatch
  const dispatch = useDispatch();
  const Navigate = useNavigate();


  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (!FirstName || !LastName || !Email || !Password || !CPassword) {
        return Swal.fire({
          icon: "question",
          title: "Details Not Provided",
          text: "Please Fill All Fields",
        });
      }
      dispatch(showLoading())
      const { data } = await axios.post(`/api/users/register`, { FirstName, LastName, Email, Password, CPassword })
      dispatch(hideLoading())
      if (data.success) {
        Swal.fire({
          position: "center",
          icon: "success",
          title: `${FirstName} Register Successfully`,
          showConfirmButton: false,
          timer: 1500
        });

        Navigate('/login')
      }
    } catch (error) {
      dispatch(hideLoading())
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Something went wrong! Please try again later",
      });
    }
  }

  return (
    <>
      {
        loading ? <Spin size="large" className='spinner mx-auto flex items-center mt-10' /> :
          <div className='Shadow1 login_main lg:w-[40%] md:w-[90%] pt-10 rounded-xl mx-auto mt-10 '>

            <section className=' mx-auto '>
              <img src={login_logo} alt="error" className=' mx-auto bg-[#44C6FE] p-7 rounded-full w-[100px] h-[100px] ' />
            </section>

            <section className='  w-[100%]  mx-auto py-10 px-10 top-[50%]   '>
              <form action="" onSubmit={handleSubmit} >
                <Input onChange={e => setEmail(e.target.value)} placeholder="Enter Email" type='email' prefix={<MailOutlined />} className=' mb-6 w-[100%] ' />

                <div className='flex items justify-between'>
                  <Input onChange={e => setFirstName(e.target.value)} placeholder="Enter First Name" prefix={<UserOutlined />} className=' mb-6 w-[100%] mr-6' />
                  <Input onChange={e => setLastName(e.target.value)} placeholder="Enter Last Name" prefix={<UserOutlined />} className=' mb-6 w-[100%] ml-6' />

                </div>

                <div className='flex items justify-between'>
                  <Input onChange={e => setPassword(e.target.value)} placeholder="Enter Password" type="password" prefix={<LockOutlined />} className=' mb-6 w-[100%] mr-6' />
                  <Input onChange={e => setCPassword(e.target.value)} placeholder="Re-Enter Password" type="password" prefix={<LockOutlined />} className=' mb-6 w-[100%] ml-6' />
                </div>
                <div className='flex items-center flex-col'>
                  <button class="loginbtn" role="button">Signup</button>
                  <Link to='/login'><p className='pt-4'>Already have Account</p></Link>
                </div>
              </form>


            </section>


          </div>
      }
    </>
  )
}
