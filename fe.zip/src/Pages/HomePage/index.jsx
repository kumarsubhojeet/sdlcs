import React, { useState, useEffect } from 'react'
import axios from 'axios';
import { SearchOutlined } from '@ant-design/icons';
import { Input } from 'antd';
import location_pin from '../../Assets/Images/location_pin.jpg'
import { MdLocationOn } from "react-icons/md";
import { CiGlobe } from "react-icons/ci";
import { FaTemperatureHigh } from "react-icons/fa";
import { FaTemperatureArrowUp, FaTemperatureArrowDown } from "react-icons/fa6";
import { FaWater } from "react-icons/fa";
import { TiWeatherCloudy } from "react-icons/ti";
import { FaMapSigns } from "react-icons/fa";
import { MdGrain } from "react-icons/md";

export default function Home() {
  const [City, setCity] = useState('');
  const [weather, setWeather] = useState([])
  const APIKEY = `f6cffe986f97518b013c731cba9ec6c8`

  const APICALL = async () => {
    try {
      const response = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?q=${City}&appid=${APIKEY}&units=metric`);

      setWeather(response.data);
      console.log(weather);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    APICALL();
  }, []);

  return (
    <>
      <div>
        <div className="input_bar w-[30%] mx-auto mt-10 " >
          <Input onChange={e => setCity(e.target.value)} placeholder="Enter City Name..." prefix={<SearchOutlined onClick={APICALL} className=' cursor-pointer hover:font-bold hover:text-xl ' />} />
          <br />
        </div>

        <div className="outputBar flex items-center flex-col mt-10 text-base text-gray-600 font-semibold ">
          {
            weather ?
              <div className='shadow2   w-[40%] mx-auto '>
                <div className=' bg-[#1D5A89] pl-10 py-2 text-white  '>
                  <h1 className='TopNavFont flex items-center text-2xl '><MdLocationOn className=' text-2xl ' />{weather?.name}</h1>
                  <h1 className='TopNavFont flex items-center '><CiGlobe />{weather?.sys?.country}</h1>

                </div>

                <div className='TopNavFont  pl-10 py-2 text-black'>
                  <h1 className='flex items-center text-lg text-black'><FaTemperatureHigh className='mr-2' />{weather?.main?.temp} <sup>o</sup>C </h1>
                  <h1 className='flex items-center text-lg text-black'><FaTemperatureArrowUp className='mr-2' />{weather?.main?.temp_max} <sup>o</sup>C </h1>
                  <h1 className='flex items-center text-lg text-black'><FaTemperatureArrowDown className='mr-2' />{weather?.main?.temp_min} <sup>o</sup>C </h1>
                  <h1 className='flex items-center text-lg text-black'><MdGrain className='mr-2' />{weather?.main?.humidity}</h1>
                  <h1 className='flex items-center text-lg text-black'><FaWater className='mr-2' />{weather?.main?.sea_level}</h1>

                  <h1 className='flex items-center text-lg text-black'><TiWeatherCloudy className='mr-2' />{weather?.weather?.main}</h1>

                  <h1 className='flex items-center text-lg text-black'><FaMapSigns className='mr-2' />3.8553,</h1>
                  <h1 className='flex items-center text-lg text-black'><FaMapSigns className='mr-2' />3.8553,</h1>
                </div>
              </div>

              : <>Null</>
          }
        </div>
      </div>
    </>
  )
}
