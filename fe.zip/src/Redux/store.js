import { configureStore } from '@reduxjs/toolkit';
import { alertSlice } from "./Slice/alertSlice";
import { authSlice } from './Slice/UserSlice';

export default configureStore({
  reducer: {
    alerts: alertSlice.reducer,
    auth: authSlice.reducer,
  },
});
