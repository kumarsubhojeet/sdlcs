import React from 'react'
import { Routes, Route } from "react-router-dom";
import './App.css'
import Home from './Pages/HomePage/index'
import Login from './Pages/Register/Login'
import Signup from './Pages/Register/Signup'
import TopNavbar from './Components/Navbar/TopNav'

function App() {
  return (
    <>
    <TopNavbar/>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
      </Routes>
    </>
  )
}

export default App