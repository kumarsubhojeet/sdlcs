const mongoose = require('mongoose');

const dbConnect = async() => {
    try {
        await mongoose.connect(`mongodb+srv://subhojeet567:Subho8002@cluster0.bquselz.mongodb.net/?retryWrites=true&w=majority` , {
        });
        console.log('DB Conneted Successful');
    } catch (error) {
        console.log(error);
    }
}

module.exports = dbConnect;