const express = require('express');
const userRegister = require("../Controller/UserCtrl");
const loginController = require("../Controller/UserCtrl");
const userAuth = require("../Middlewares/AuthMiddleware")

const router = express.Router();

router.post('/register', userAuth ,userRegister)
router.post('/login', loginController)

module.exports = router;