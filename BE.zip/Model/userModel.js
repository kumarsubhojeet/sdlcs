const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const JWT = require('jsonwebtoken')

const userSchema = new mongoose.Schema({
    FirstName: {
        required: [true, "Name is required"],
        type: String,
    },
    LastName: {
        required: [true, "Name is required"],
        type: String,
    },
    Email: {
        required: [true, "Email is required"],
        type: String,
    },
    Password: {
        required: [true, "Password is required"],
        type: String,
        select: true,
    },
}, {
    timestamps: true,
})

//Middlewares

userSchema.pre('save', async function () {
    const salt = await bcrypt.genSalt(10)
    this.Password = await bcrypt.hash(this.Password, salt);
})

//Compare Password
userSchema.methods.comparePassword = async function (userPassword) {
    const isMatch = await bcrypt.compare(userPassword , this.Password)
    return isMatch;
}

//JWT
userSchema.methods.createJWT = function () {
    return JWT.sign({ userId: this._id }, process.env.JWT_SECRET, { expiresIn: '5d' })
}

const User = mongoose.model('User', userSchema)
module.exports = User
