const express = require('express');
const dbConnect = require('./config/DB/ConnectDB')
const UserRoute = require('./Routes/UserRoute');
const cors = require('cors')
const dotenv = require('dotenv')
const errorMiddleware = require('./Middlewares/errorhandling');
require('express-async-errors');
const app = express();

//Dot ENV config
dotenv.config();

dbConnect()
app.use(express.json());
app.use(cors());
//Routing
app.use('/api/users' , UserRoute)

//Middleware
app.use(errorMiddleware)

const PORT = process.env.PORT || 8080;
app.listen(PORT , console.log( `listening on ${PORT}`));