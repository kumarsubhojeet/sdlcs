const express = require('express');
const userModel = require('../Model/userModel')

const userRegister = async (req, res, next) => {
    try {
        const { FirstName, LastName, Email, Password } = req.body
        // Validate
        if (!FirstName || !LastName || !Email || !Password) {
            next("Please Fill All the Fields")
        }
        const existingUser = await userModel.findOne({ Email })

        //Existing User
        if (existingUser) {
            next("User already exists please login")
        }
        else {
            const user = await userModel.create({ FirstName, LastName, Email, Password })
            //token 
            const token = user.createJWT()
            res.status(201).send({
                success: true,
                message: "User Successfully Registered",
                user,
                token
            })

        }


    } catch (error) {
        next(error);
    }
}

const loginController = async (req, res, next) => {
    const { Email, Password } = req.body
    //validation
    if (!Email || !Password) {
        next("Please Provide All Fields");
    }
    //find user by Email
    const user = await userModel.findOne({ Email }).select("+Password");
    if (!user) {
        next("Invalid Useraname or Password");
    }
    console.log(user)
    //compare Password
    const isMatch = await user.comparePassword(Password);
    if (!isMatch) {
        next("Invalid Useraname or Password");
    }
    user.Password = undefined;
    const token = user.createJWT();
    res.status(200).json({
        success: true,
        message: "Login SUccessfully",
        user,
        token,
    });
};

module.exports = userRegister;
module.exports = loginController;